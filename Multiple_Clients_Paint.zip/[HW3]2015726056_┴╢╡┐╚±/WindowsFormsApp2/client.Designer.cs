﻿namespace WindowsFormsApp2
{
    partial class clientForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(clientForm));
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.toolStripDropDownButton1 = new System.Windows.Forms.ToolStripDropDownButton();
            this.handToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pencilToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.lineToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.circleToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.rectToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripDropDownButton2 = new System.Windows.Forms.ToolStripDropDownButton();
            this.line1ToolStrip = new System.Windows.Forms.ToolStripMenuItem();
            this.line2ToolStrip = new System.Windows.Forms.ToolStripMenuItem();
            this.line3ToolStrip = new System.Windows.Forms.ToolStripMenuItem();
            this.line4ToolStrip = new System.Windows.Forms.ToolStripMenuItem();
            this.line5ToolStrip = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.btnFill = new System.Windows.Forms.ToolStripButton();
            this.btnColor1 = new System.Windows.Forms.ToolStripButton();
            this.btnColor2 = new System.Windows.Forms.ToolStripButton();
            this.panel1 = new WindowsFormsApp2.clientForm.DoubleBufferPanel();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.txtMessage = new System.Windows.Forms.TextBox();
            this.btnSay = new System.Windows.Forms.Button();
            this.cld = new System.Windows.Forms.ColorDialog();
            this.toolStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // toolStrip1
            // 
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripDropDownButton1,
            this.toolStripDropDownButton2,
            this.toolStripSeparator1,
            this.btnFill,
            this.btnColor1,
            this.btnColor2});
            this.toolStrip1.Location = new System.Drawing.Point(0, 0);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(800, 25);
            this.toolStrip1.TabIndex = 0;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // toolStripDropDownButton1
            // 
            this.toolStripDropDownButton1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripDropDownButton1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.handToolStripMenuItem,
            this.pencilToolStripMenuItem,
            this.lineToolStripMenuItem,
            this.circleToolStripMenuItem,
            this.rectToolStripMenuItem});
            this.toolStripDropDownButton1.Image = global::WindowsFormsApp2.Properties.Resources.연필;
            this.toolStripDropDownButton1.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripDropDownButton1.Name = "toolStripDropDownButton1";
            this.toolStripDropDownButton1.Size = new System.Drawing.Size(29, 22);
            this.toolStripDropDownButton1.Text = "toolStripDropDownButton1";
            // 
            // handToolStripMenuItem
            // 
            this.handToolStripMenuItem.Image = global::WindowsFormsApp2.Properties.Resources.손;
            this.handToolStripMenuItem.Name = "handToolStripMenuItem";
            this.handToolStripMenuItem.Size = new System.Drawing.Size(106, 22);
            this.handToolStripMenuItem.Text = "Hand";
            this.handToolStripMenuItem.Click += new System.EventHandler(this.handToolStripMenuItem_Click);
            // 
            // pencilToolStripMenuItem
            // 
            this.pencilToolStripMenuItem.Image = global::WindowsFormsApp2.Properties.Resources.연필;
            this.pencilToolStripMenuItem.Name = "pencilToolStripMenuItem";
            this.pencilToolStripMenuItem.Size = new System.Drawing.Size(106, 22);
            this.pencilToolStripMenuItem.Text = "Pencil";
            this.pencilToolStripMenuItem.Click += new System.EventHandler(this.pencilToolStripMenuItem_Click);
            // 
            // lineToolStripMenuItem
            // 
            this.lineToolStripMenuItem.Image = global::WindowsFormsApp2.Properties.Resources.직선;
            this.lineToolStripMenuItem.Name = "lineToolStripMenuItem";
            this.lineToolStripMenuItem.Size = new System.Drawing.Size(106, 22);
            this.lineToolStripMenuItem.Text = "Line";
            this.lineToolStripMenuItem.Click += new System.EventHandler(this.lineToolStripMenuItem_Click);
            // 
            // circleToolStripMenuItem
            // 
            this.circleToolStripMenuItem.Image = global::WindowsFormsApp2.Properties.Resources.원;
            this.circleToolStripMenuItem.Name = "circleToolStripMenuItem";
            this.circleToolStripMenuItem.Size = new System.Drawing.Size(106, 22);
            this.circleToolStripMenuItem.Text = "Circle";
            this.circleToolStripMenuItem.Click += new System.EventHandler(this.circleToolStripMenuItem_Click);
            // 
            // rectToolStripMenuItem
            // 
            this.rectToolStripMenuItem.Image = global::WindowsFormsApp2.Properties.Resources.사각형;
            this.rectToolStripMenuItem.Name = "rectToolStripMenuItem";
            this.rectToolStripMenuItem.Size = new System.Drawing.Size(106, 22);
            this.rectToolStripMenuItem.Text = "Rect";
            this.rectToolStripMenuItem.Click += new System.EventHandler(this.rectToolStripMenuItem_Click);
            // 
            // toolStripDropDownButton2
            // 
            this.toolStripDropDownButton2.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripDropDownButton2.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.line1ToolStrip,
            this.line2ToolStrip,
            this.line3ToolStrip,
            this.line4ToolStrip,
            this.line5ToolStrip});
            this.toolStripDropDownButton2.Image = global::WindowsFormsApp2.Properties.Resources.line1Button;
            this.toolStripDropDownButton2.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripDropDownButton2.Name = "toolStripDropDownButton2";
            this.toolStripDropDownButton2.Size = new System.Drawing.Size(29, 22);
            this.toolStripDropDownButton2.Text = "toolStripDropDownButton2";
            // 
            // line1ToolStrip
            // 
            this.line1ToolStrip.Image = global::WindowsFormsApp2.Properties.Resources.line1Button;
            this.line1ToolStrip.Name = "line1ToolStrip";
            this.line1ToolStrip.Size = new System.Drawing.Size(81, 22);
            this.line1ToolStrip.Text = "1";
            this.line1ToolStrip.Click += new System.EventHandler(this.line1ToolStrip_Click);
            // 
            // line2ToolStrip
            // 
            this.line2ToolStrip.Image = global::WindowsFormsApp2.Properties.Resources.line2Button;
            this.line2ToolStrip.Name = "line2ToolStrip";
            this.line2ToolStrip.Size = new System.Drawing.Size(81, 22);
            this.line2ToolStrip.Text = "2";
            this.line2ToolStrip.Click += new System.EventHandler(this.line2ToolStrip_Click);
            // 
            // line3ToolStrip
            // 
            this.line3ToolStrip.Image = global::WindowsFormsApp2.Properties.Resources.line3Button;
            this.line3ToolStrip.Name = "line3ToolStrip";
            this.line3ToolStrip.Size = new System.Drawing.Size(81, 22);
            this.line3ToolStrip.Text = "3";
            this.line3ToolStrip.Click += new System.EventHandler(this.line3ToolStrip_Click);
            // 
            // line4ToolStrip
            // 
            this.line4ToolStrip.Image = global::WindowsFormsApp2.Properties.Resources.line4Button;
            this.line4ToolStrip.Name = "line4ToolStrip";
            this.line4ToolStrip.Size = new System.Drawing.Size(81, 22);
            this.line4ToolStrip.Text = "4";
            this.line4ToolStrip.Click += new System.EventHandler(this.line4ToolStrip_Click);
            // 
            // line5ToolStrip
            // 
            this.line5ToolStrip.Image = global::WindowsFormsApp2.Properties.Resources.line5Button;
            this.line5ToolStrip.Name = "line5ToolStrip";
            this.line5ToolStrip.Size = new System.Drawing.Size(81, 22);
            this.line5ToolStrip.Text = "5";
            this.line5ToolStrip.Click += new System.EventHandler(this.line5ToolStrip_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(6, 25);
            // 
            // btnFill
            // 
            this.btnFill.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.btnFill.Image = ((System.Drawing.Image)(resources.GetObject("btnFill.Image")));
            this.btnFill.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnFill.Name = "btnFill";
            this.btnFill.Size = new System.Drawing.Size(47, 22);
            this.btnFill.Text = "채우기";
            this.btnFill.Click += new System.EventHandler(this.btnFill_Click);
            // 
            // btnColor1
            // 
            this.btnColor1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.None;
            this.btnColor1.ForeColor = System.Drawing.SystemColors.Window;
            this.btnColor1.Image = ((System.Drawing.Image)(resources.GetObject("btnColor1.Image")));
            this.btnColor1.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnColor1.Name = "btnColor1";
            this.btnColor1.Size = new System.Drawing.Size(23, 22);
            this.btnColor1.Text = "toolStripButton2";
            this.btnColor1.Click += new System.EventHandler(this.btnColor1_Click);
            // 
            // btnColor2
            // 
            this.btnColor2.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.None;
            this.btnColor2.Image = ((System.Drawing.Image)(resources.GetObject("btnColor2.Image")));
            this.btnColor2.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnColor2.Name = "btnColor2";
            this.btnColor2.Size = new System.Drawing.Size(23, 22);
            this.btnColor2.Text = "toolStripButton1";
            this.btnColor2.Click += new System.EventHandler(this.btnColor2_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.Window;
            this.panel1.Location = new System.Drawing.Point(0, 28);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(800, 328);
            this.panel1.TabIndex = 1;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            this.panel1.MouseDown += new System.Windows.Forms.MouseEventHandler(this.panel1_MouseDown);
            this.panel1.MouseMove += new System.Windows.Forms.MouseEventHandler(this.panel1_MouseMove);
            this.panel1.MouseUp += new System.Windows.Forms.MouseEventHandler(this.panel1_MouseUp);
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(0, 357);
            this.textBox1.Multiline = true;
            this.textBox1.Name = "textBox1";
            this.textBox1.ReadOnly = true;
            this.textBox1.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.textBox1.Size = new System.Drawing.Size(800, 70);
            this.textBox1.TabIndex = 2;
            // 
            // txtMessage
            // 
            this.txtMessage.Location = new System.Drawing.Point(0, 427);
            this.txtMessage.Name = "txtMessage";
            this.txtMessage.Size = new System.Drawing.Size(742, 21);
            this.txtMessage.TabIndex = 2;
            this.txtMessage.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtMessage_KeyDown);
            this.txtMessage.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txtMessage_KeyUp);
            // 
            // btnSay
            // 
            this.btnSay.Location = new System.Drawing.Point(743, 427);
            this.btnSay.Name = "btnSay";
            this.btnSay.Size = new System.Drawing.Size(57, 21);
            this.btnSay.TabIndex = 3;
            this.btnSay.Text = "Say";
            this.btnSay.UseVisualStyleBackColor = true;
            this.btnSay.Click += new System.EventHandler(this.btnSay_Click);
            // 
            // clientForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnSay);
            this.Controls.Add(this.txtMessage);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.toolStrip1);
            this.Name = "clientForm";
            this.Text = "client";
            this.Load += new System.EventHandler(this.clientForm_Load);
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripDropDownButton toolStripDropDownButton1;
        private System.Windows.Forms.ToolStripMenuItem handToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem pencilToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem lineToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem circleToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem rectToolStripMenuItem;
        private System.Windows.Forms.ToolStripDropDownButton toolStripDropDownButton2;
        private System.Windows.Forms.ToolStripMenuItem line1ToolStrip;
        private System.Windows.Forms.ToolStripMenuItem line2ToolStrip;
        private System.Windows.Forms.ToolStripMenuItem line3ToolStrip;
        private System.Windows.Forms.ToolStripMenuItem line4ToolStrip;
        private System.Windows.Forms.ToolStripMenuItem line5ToolStrip;
        private System.Windows.Forms.ToolStripButton btnFill;
        private System.Windows.Forms.ToolStripButton btnColor1;
        private System.Windows.Forms.ToolStripButton btnColor2;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox txtMessage;
        private System.Windows.Forms.Button btnSay;
        private System.Windows.Forms.ColorDialog cld;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private DoubleBufferPanel panel1;
    }
}