﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Drawing.Drawing2D;
using System.Threading;
using System.IO;
using System.Collections;
using System.Net;
using System.Net.Sockets;
using System.Diagnostics;
using System.Runtime.Serialization.Formatters.Binary;
using hw3Library;

namespace WindowsFormsApp2
{
    public partial class clientForm : Form
    {
        private bool hand;
        private bool pencil;
        private bool line;
        private bool rect;
        private bool circle;
        
        private Point start;
        private Point finish;
        private Pen pen;
        private int nline;
        private int nrect;
        private int ncircle;
        private int npen;
        private int i;
        private int thick;
        private bool isSolid;
        //private List<MyPen> mypens;
        //private List<MyLines> mylines;
        //private List<MyRect> myrects;
        //private List<MyCircle> mycircles;

        private MyPen[] mypens;
        private MyLines[] mylines;
        private MyRect[] myrects;
        private MyRect[] tempMyRects;
        private MyCircle[] mycircles;
        private static string name = clientModal.cliName;

        private int count;
        private bool isClickedFill;
        private List<int> order;
        private byte[] sendBuffer = new byte[1024 * 1024];
        private byte[] readBuffer = new byte[1024 * 1024];
        private int nRead;
        private NetworkStream m_Stream;  //네트워크 스트링        
        public Graphics screen;
        public Graphics screen1;

        

        private double nowRatio = 1;
        private double beforeRatio = 1;

        private int tempFinishX;
        private int tempFinishY;


        private bool isDragOn = false;

        public clientForm()
        {                        
            InitializeComponent();
            panel1.MouseWheel += new MouseEventHandler(panel1_MouseWheel);
            this.ActiveControl = txtMessage;
            SetupVar();                                           
        }

        public class DoubleBufferPanel : Panel
        {
            public DoubleBufferPanel()
            {
                this.SetStyle(ControlStyles.DoubleBuffer | ControlStyles.UserPaint |
                    ControlStyles.AllPaintingInWmPaint, true);
                this.UpdateStyles();
            }
        }

        private void panel1_MouseWheel(object sender, MouseEventArgs e)
        {
            screen1 = this.panel1.CreateGraphics();
            int lines = e.Delta * SystemInformation.MouseWheelScrollLines / 120;
            DoubleBufferPanel pb = (DoubleBufferPanel)sender;
            int count_rect = 0;
            int count_pen = 0;
            int count_circle = 0;
            int count_line = 0;            
            if (hand != true)
                return;

            if (lines > 0)
            {
                nowRatio -= 1;
                if (nowRatio < 1)
                {
                    nowRatio = 1;
                    return;
                }
            }
            else if (lines < 0)
            {
                nowRatio += 1;
                if (nowRatio > 10)
                {
                    nowRatio = 10;
                    return;
                }
                
            }           
            for (int j = 0; j < order.Count; j++)
            {                
                switch (order[j])
                {
                    case 1:
                        {
                            if (nowRatio - beforeRatio > 0) //확대 구현해야함
                            {
                                penExpand(count_pen, e);
                            }
                            else
                                penReduce(count_pen, e);
                            
                            count_pen++;
                            break;
                        }
                    case 2:
                        {
                            if (nowRatio - beforeRatio > 0) //확대 구현해야함
                            {
                                lineExpand(count_line, e);
                                
                            }
                            else
                                lineReduce(count_line, e);

                            count_line++;
                            break;
                        }
                    case 3:
                        {
                            if (nowRatio - beforeRatio > 0) //확대 구현해야함
                            {                                
                                rectExpand(count_rect, e);                                
                            }
                            else
                                rectReduce(count_rect, e);

                            count_rect++;
                            break;
                        }
                    case 4:
                        {
                            if (nowRatio - beforeRatio > 0) //확대 구현해야함
                            {
                                circleExpand(count_circle, e);
                            }
                            else
                                circleReduce(count_circle, e);

                            count_circle++;
                            break;
                        }
                }               
            }
                        
            beforeRatio = nowRatio;
            panel1.Invalidate();
        }
        public void penExpand(int index , MouseEventArgs e)
        {            
            MyPen tempPen = mypens[index];
            int tempRatio = (int)nowRatio - (int)beforeRatio;
            double tempStartX;
            double tempStartY;
            double convertX;
            double convertY;
                       
            //펜부터 하쟝ㅎㅎ
            for (int i = 0; i < tempPen.getLength(); i++)
            {                
                tempStartX = tempPen.getPoint1(i).X;
                tempStartY = tempPen.getPoint1(i).Y;
                convertX = (nowRatio * tempStartX - tempRatio * e.X) / beforeRatio;
                convertY = (nowRatio * tempStartY - tempRatio * e.Y) / beforeRatio;

                Point point = new Point((int)convertX, (int)convertY);
                mypens[index].setPoint1(i, point);
            }

            Pen pen = new Pen(tempPen.getLineColor());
            pen.Width = tempPen.getThick();

            for (int j = 1; j < tempPen.getLength(); j++)
            {
                screen1.DrawLine(pen, mypens[index].getPoint1(j), mypens[index].getPoint1(j - 1));
                panel1.Invalidate();
            }
        }

        public void lineExpand(int index , MouseEventArgs e)
        {
            MyLines tempLine = mylines[index];
            Point point;
            int tempRatio = (int)nowRatio - (int)beforeRatio;
            double tempX;
            double tempY;            
            double convertX;
            double convertY;
            tempX = tempLine.getPoint1().X;
            tempY = tempLine.getPoint1().Y;
            convertX = (nowRatio * tempX - tempRatio * e.X) / beforeRatio;
            convertY = (nowRatio * tempY - tempRatio * e.Y) / beforeRatio;
            point = new Point((int)convertX, (int)convertY);
            mylines[index].setPoint1(point);

            tempX = tempLine.getPoint2().X;
            tempY = tempLine.getPoint2().Y;
            convertX = (nowRatio * tempX - tempRatio * e.X) / beforeRatio;
            convertY = (nowRatio * tempY - tempRatio * e.Y) / beforeRatio;
            point = new Point((int)convertX, (int)convertY);
            mylines[index].setPoint2(point);

            Pen pen = new Pen(mylines[index].getLineColor());
            pen.Width = mylines[index].getThick();
            screen1.DrawLine(pen, mylines[index].getPoint1(), mylines[index].getPoint2());
            panel1.Invalidate();

        }

        public void rectExpand(int index , MouseEventArgs e)
        {            
            MyRect tempRect = myrects[index];                
            double tempStartX = tempRect.getPointX();
            double tempStartY = tempRect.getPointY();
            double tempWidth = tempRect.getWidth();            
            double tempHeight = tempRect.getHeight();         
            double convertX;
            double convertY;
            int tempRatio = (int)nowRatio - (int)beforeRatio;
            convertX = (nowRatio * tempStartX - tempRatio * e.X) / beforeRatio;        
            convertY = (nowRatio * tempStartY - tempRatio * e.Y) / beforeRatio;
            
            tempWidth = (nowRatio / beforeRatio) * tempWidth;
            tempHeight = (nowRatio / beforeRatio) * tempHeight;               
            myrects[index].setRect1(convertX, convertY, convertX + tempWidth, convertY + tempHeight);
            Pen pen = new Pen(myrects[index].getLineColor());
            pen.Width = myrects[index].getThick();
            screen1.DrawRectangle(pen, myrects[index].getRect());
            SolidBrush br = new SolidBrush(myrects[index].getBackColor());
            screen1.FillRectangle(br, myrects[index].getRect().X + (myrects[index].getThick() / 2) + (myrects[index].getThick() % 2),                        
                myrects[index].getRect().Y + (myrects[index].getThick() / 2) + (myrects[index].getThick() % 2),                            
                myrects[index].getRect().Width - myrects[index].getThick(), myrects[index].getRect().Height - myrects[index].getThick());            
        }
        public void circleExpand(int index, MouseEventArgs e)
        {
            MyCircle tempCircle = mycircles[index];
            Point startP;
            Point finishP;
            double tempStartX = tempCircle.getRectC().X;
            double tempStartY = tempCircle.getRectC().Y;
            double tempWidth = tempCircle.getRectC().Width;
            double tempHeight = tempCircle.getRectC().Height;            
            double convertX;
            double convertY;
            int tempRatio = (int)nowRatio - (int)beforeRatio;
            convertX = (nowRatio * tempStartX - tempRatio * e.X) / beforeRatio;
            convertY = (nowRatio * tempStartY - tempRatio * e.Y) / beforeRatio;
            tempWidth = (nowRatio / beforeRatio) * tempWidth;
            tempHeight = (nowRatio / beforeRatio) * tempHeight;            
            startP = new Point((int)convertX, (int)convertY);
            finishP = new Point((int)(convertX + tempWidth), (int)(convertY + tempHeight));
            mycircles[index].setRectC1(startP, finishP);
            Pen pen = new Pen(mycircles[index].getLineColor());
            pen.Width = mycircles[index].getThick();
            screen1.DrawEllipse(pen, mycircles[index].getRectC());
            SolidBrush br = new SolidBrush(mycircles[index].getBackColor());
            screen1.FillEllipse(br, mycircles[index].getRectC().X + (mycircles[index].getThick() / 2) + (mycircles[index].getThick() % 2),
                                     mycircles[index].getRectC().Y + (mycircles[index].getThick() / 2) + (mycircles[index].getThick() % 2),
                                     mycircles[index].getRectC().Width - mycircles[index].getThick(), mycircles[index].getRectC().Height - mycircles[index].getThick());
        }
        public void penReduce(int index, MouseEventArgs e)
        {
            MyPen tempPen = mypens[index];
            int tempRatio = (int)beforeRatio - (int)nowRatio;
            double tempStartX;
            double tempStartY;
            double convertX;
            double convertY;
            
            for (int i = 0; i < tempPen.getLength(); i++)
            {
                tempStartX = tempPen.getPoint1(i).X;
                tempStartY = tempPen.getPoint1(i).Y;
                convertX = (nowRatio * tempStartX + (tempRatio) * e.X) / beforeRatio;
                convertY = (nowRatio * tempStartY + (tempRatio) * e.Y) / beforeRatio;

                Point point = new Point((int)convertX, (int)convertY);
                mypens[index].setPoint1(i, point);
            }

            Pen pen = new Pen(tempPen.getLineColor());
            pen.Width = tempPen.getThick();

            for (int j = 1; j < tempPen.getLength(); j++)
            {
                screen1.DrawLine(pen, mypens[index].getPoint1(j), mypens[index].getPoint1(j - 1));
            }
        }
        public void lineReduce(int index, MouseEventArgs e)
        {
            MyLines tempLine = mylines[index];
            Point point;
            int tempRatio = (int)beforeRatio - (int)nowRatio;
            double tempX;
            double tempY;
            double convertX;
            double convertY;
            tempX = tempLine.getPoint1().X;
            tempY = tempLine.getPoint1().Y;
            convertX = (nowRatio * tempX + (tempRatio) * e.X) / beforeRatio;
            convertY = (nowRatio * tempY + (tempRatio) * e.Y) / beforeRatio;
            point = new Point((int)convertX, (int)convertY);
            mylines[index].setPoint1(point);

            tempX = tempLine.getPoint2().X;
            tempY = tempLine.getPoint2().Y;
            convertX = (nowRatio * tempX + tempRatio * e.X) / beforeRatio;
            convertY = (nowRatio * tempY + tempRatio * e.Y) / beforeRatio;
            point = new Point((int)convertX, (int)convertY);
            mylines[index].setPoint2(point);

            Pen pen = new Pen(mylines[index].getLineColor());
            pen.Width = mylines[index].getThick();
            screen1.DrawLine(pen, mylines[index].getPoint1(), mylines[index].getPoint2());
        }
        public void rectReduce(int index, MouseEventArgs e)
        {            
            MyRect tempRect = myrects[index];
            double tempStartX = tempRect.getPointX();
            double tempStartY = tempRect.getPointY();
            double tempWidth = tempRect.getWidth();
            double tempHeight = tempRect.getHeight();
            double tempFinishX = tempStartX + tempWidth;
            double tempFinishY = tempStartY + tempHeight;
            double convertX;
            double convertY;
            int tempRatio = (int)beforeRatio - (int)nowRatio;
            convertX = (nowRatio * tempStartX + (tempRatio) * e.X) / beforeRatio;
            convertY = (nowRatio * tempStartY + (tempRatio) * e.Y) / beforeRatio;
            tempWidth = (nowRatio / beforeRatio) * tempWidth;
            tempHeight = (nowRatio / beforeRatio) * tempHeight;                        
            myrects[index].setRect1(convertX, convertY, convertX + tempWidth, convertY + tempHeight);

            Pen pen = new Pen(myrects[index].getLineColor());
            pen.Width = myrects[index].getThick();
            screen1.DrawRectangle(pen, myrects[index].getRect());
            SolidBrush br = new SolidBrush(myrects[index].getBackColor());
            screen1.FillRectangle(br, myrects[index].getRect().X + (myrects[index].getThick() / 2) + (myrects[index].getThick() % 2),
                myrects[index].getRect().Y + (myrects[index].getThick() / 2) + (myrects[index].getThick() % 2),
                myrects[index].getRect().Width - myrects[index].getThick(), myrects[index].getRect().Height - myrects[index].getThick());
            
        }
        public void circleReduce(int index, MouseEventArgs e)
        {
            MyCircle tempCircle = mycircles[index];
            Point startP;
            Point finishP;
            double tempStartX = tempCircle.getRectC().X;
            double tempStartY = tempCircle.getRectC().Y;
            double tempWidth = tempCircle.getRectC().Width;
            double tempHeight = tempCircle.getRectC().Height;
            double convertX;
            double convertY;
            int tempRatio = (int)beforeRatio - (int)nowRatio;
            convertX = (nowRatio * tempStartX + (tempRatio) * e.X) / beforeRatio;
            convertY = (nowRatio * tempStartY + (tempRatio) * e.Y) / beforeRatio;
            tempWidth = (nowRatio / beforeRatio) * tempWidth;
            tempHeight = (nowRatio / beforeRatio) * tempHeight;            
            startP = new Point((int)convertX, (int)convertY);
            finishP = new Point((int)(convertX + tempWidth), (int)(convertY + tempHeight));
            mycircles[index].setRectC1(startP, finishP);
            Pen pen = new Pen(mycircles[index].getLineColor());
            pen.Width = mycircles[index].getThick();
            screen1.DrawEllipse(pen, mycircles[index].getRectC());
            SolidBrush br = new SolidBrush(mycircles[index].getBackColor());
            screen1.FillEllipse(br, mycircles[index].getRectC().X + (mycircles[index].getThick() / 2) + (mycircles[index].getThick() % 2),
                                     mycircles[index].getRectC().Y + (mycircles[index].getThick() / 2) + (mycircles[index].getThick() % 2),
                                     mycircles[index].getRectC().Width - mycircles[index].getThick(), mycircles[index].getRectC().Height - mycircles[index].getThick());
        }

        private void SetupVar()
        {            
            i = 0;
            thick = 1;
            isSolid = true;
            pencil = false;
            line = false;
            rect = false;
            circle = false;
            start = new Point(0, 0);
            finish = new Point(0, 0);
            pen = new Pen(Color.Black);                        

            mylines = new MyLines[1000];
            myrects = new MyRect[1000];
            mycircles = new MyCircle[1000];
            mypens = new MyPen[1000];
            nline = 0;
            nrect = 0;
            ncircle = 0;
            npen = 0;
            isClickedFill = false;
            order = new List<int>();
            
            count = 0;
            
            SetupMine();
            ReceiveAll();
            ClientThread();
        }

        private void ReceiveAll()
        {
            NetworkStream stream = clientModal.client.GetStream();
            screen1 = this.panel1.CreateGraphics();
            int nRead;
            
            while (true)
            {                
                nRead = stream.Read(readBuffer, 0, 1024 * 1024);
                Packet packet = (Packet)Packet.Desserialize(readBuffer);
                switch ((int)packet.type)
                {
                    case (int)PacketType.펜:
                        {
                            Packet.Pen m_pen;
                            m_pen = new Packet.Pen();
                            m_pen = (Packet.Pen)Packet.Desserialize(readBuffer);
                            mypens[npen++] = m_pen.pen;
                            order.Add(1);
                            Pen pen = new Pen(m_pen.pen.getLineColor());
                            pen.Width = m_pen.pen.getThick();
                            for (int j = 1; j < m_pen.pen.getLength(); j++)
                            {
                                screen1.DrawLine(pen, m_pen.pen.getPoint1(j), m_pen.pen.getPoint1(j - 1));
                            }

                            break;
                        }
                    case (int)PacketType.선:
                        {
                            Packet.Line m_line;
                            m_line = new Packet.Line();
                            m_line = (Packet.Line)Packet.Desserialize(readBuffer);
                            mylines[nline++] = m_line.line;
                            order.Add(2);
                            Pen pen = new Pen(m_line.line.getLineColor());
                            pen.Width = m_line.line.getThick();
                            screen1.DrawLine(pen, m_line.line.getPoint1(), m_line.line.getPoint2());                            
                            break;
                        }
                    case (int)PacketType.사각형:
                        {
                            Packet.Rect m_rect;
                            m_rect = new Packet.Rect();
                            m_rect = (Packet.Rect)Packet.Desserialize(readBuffer);
                            myrects[nrect++] = m_rect.rect;
                            order.Add(3);
                            Pen pen = new Pen(m_rect.rect.getLineColor());
                            pen.Width = m_rect.rect.getThick();
                            screen1.DrawRectangle(pen, m_rect.rect.getRect());
                            SolidBrush br = new SolidBrush(m_rect.rect.getBackColor());
                            screen1.FillRectangle(br, m_rect.rect.getRect().X + (m_rect.rect.getThick() / 2) + (m_rect.rect.getThick() % 2),
                              m_rect.rect.getRect().Y + (m_rect.rect.getThick() / 2) + (m_rect.rect.getThick() % 2),
                              m_rect.rect.getRect().Width - m_rect.rect.getThick(), m_rect.rect.getRect().Height - m_rect.rect.getThick());
                            break;
                        }
                    case (int)PacketType.원:
                        {
                            Packet.Circle m_circle;
                            m_circle = new Packet.Circle();
                            m_circle = (Packet.Circle)Packet.Desserialize(readBuffer);
                            mycircles[ncircle++] = m_circle.circle;
                            order.Add(4);
                            Pen pen = new Pen(m_circle.circle.getLineColor());
                            pen.Width = m_circle.circle.getThick();
                            screen1.DrawEllipse(pen, m_circle.circle.getRectC());
                            SolidBrush br = new SolidBrush(m_circle.circle.getBackColor());
                            screen1.FillEllipse(br, m_circle.circle.getRectC().X + (m_circle.circle.getThick() / 2) + (m_circle.circle.getThick() % 2),
                              m_circle.circle.getRectC().Y + (m_circle.circle.getThick() / 2) + (m_circle.circle.getThick() % 2),
                              m_circle.circle.getRectC().Width - m_circle.circle.getThick(), m_circle.circle.getRectC().Height - m_circle.circle.getThick());
                            break;
                        }
                    case (int)PacketType.끝:
                        {
                            return;                            
                        }                      
                }
                
            }
            

        }

        private void ClientThread()
        {            
            Thread serverThread;
            screen = this.panel1.CreateGraphics();
            serverThread = new Thread(new ThreadStart(Received));
            serverThread.Start();
        }

        private void Received()
        {            
            NetworkStream stream = clientModal.client.GetStream();            
            

            while (true)
            {
                
                nRead = stream.Read(readBuffer, 0, 1024 * 1024);
                if(nRead > 0)
                {
                    try
                    {
                        Packet packet = (Packet)Packet.Desserialize(readBuffer);                        
                        switch ((int)packet.type)
                        {
                            case (int)PacketType.펜:
                                {                                    
                                    Packet.Pen m_pen = new Packet.Pen();

                                    m_pen = (Packet.Pen)Packet.Desserialize(readBuffer);
                                    mypens[npen++] = m_pen.pen;
                                    order.Add(1);
                                    //mypens.Add(m_pen.pen);
                                    Pen pen = new Pen(m_pen.pen.getLineColor());
                                    pen.Width = m_pen.pen.getThick();
                                    for (int j = 1; j < m_pen.pen.getLength(); j++)
                                    {
                                        screen.DrawLine(pen, m_pen.pen.getPoint1(j), m_pen.pen.getPoint1(j - 1));                                        
                                    }                                    
                                    //panel1.Invalidate(true);
                                    //panel1.Update();
                                    break;
                                }
                                
                            case (int)PacketType.선:
                                {                                    
                                    Packet.Line m_line = new Packet.Line();
                                    m_line = (Packet.Line)Packet.Desserialize(readBuffer);
                                    mylines[nline++] = m_line.line;
                                    order.Add(2);
                                    Pen pen = new Pen(m_line.line.getLineColor());
                                    pen.Width = m_line.line.getThick();
                                    screen.DrawLine(pen, m_line.line.getPoint1(), m_line.line.getPoint2());
                                    break;
                                }
                            case (int)PacketType.사각형:
                                {                                    
                                    Packet.Rect m_rect = new Packet.Rect();
                                    m_rect = (Packet.Rect)Packet.Desserialize(readBuffer);
                                    myrects[nrect++] = m_rect.rect;
                                    order.Add(3);
                                    Pen pen = new Pen(m_rect.rect.getLineColor());
                                    pen.Width = m_rect.rect.getThick();
                                    screen.DrawRectangle(pen, m_rect.rect.getRect());
                                    SolidBrush br = new SolidBrush(m_rect.rect.getBackColor());
                                    screen.FillRectangle(br, m_rect.rect.getRect().X + (m_rect.rect.getThick() / 2) + (m_rect.rect.getThick() % 2),
                                      m_rect.rect.getRect().Y + (m_rect.rect.getThick() / 2) + (m_rect.rect.getThick() % 2),
                                      m_rect.rect.getRect().Width - m_rect.rect.getThick(), m_rect.rect.getRect().Height - m_rect.rect.getThick());

                                    break;
                                }
                                
                            case (int)PacketType.원:
                                {                                    
                                    Packet.Circle m_circle = new Packet.Circle();
                                    //m_circle = new Packet.Circle();
                                    m_circle = (Packet.Circle)Packet.Desserialize(readBuffer);
                                    mycircles[ncircle++] = m_circle.circle;
                                    order.Add(4);
                                    Pen pen = new Pen(m_circle.circle.getLineColor());
                                    pen.Width = m_circle.circle.getThick();
                                    screen.DrawEllipse(pen, m_circle.circle.getRectC());
                                    SolidBrush br = new SolidBrush(m_circle.circle.getBackColor());
                                    screen.FillEllipse(br, m_circle.circle.getRectC().X + (m_circle.circle.getThick() / 2) + (m_circle.circle.getThick() % 2),
                                      m_circle.circle.getRectC().Y + (m_circle.circle.getThick() / 2) + (m_circle.circle.getThick() % 2),
                                      m_circle.circle.getRectC().Width - m_circle.circle.getThick(), m_circle.circle.getRectC().Height - m_circle.circle.getThick());
                                    break;
                                }

                            case (int)PacketType.메세지:
                                {
                                    Packet.Message m_message = new Packet.Message();
                                    m_message = (Packet.Message)Packet.Desserialize(readBuffer);
                                    textBox1.AppendText(m_message.name + " : " + m_message.message);
                                    textBox1.AppendText("\r\n");
                                    break;
                                }
                                
                        }
                    }
                    catch(Exception e)
                    {
                                           
                    }
                }
            }
        }        
        
        private void SetupMine()
        {
            for (i = 0; i < 100; i++)
                mypens[i] = new MyPen();
            for (i = 0; i < 100; i++)
                mylines[i] = new MyLines();
            for (i = 0; i < 100; i++)
                myrects[i] = new MyRect();
            for (i = 0; i < 100; i++)
                mycircles[i] = new MyCircle();


        }

        private void clientForm_Load(object sender, EventArgs e)
        {
            btnColor1.BackColor = Color.FromArgb(0, 0, 0);
            btnColor2.BackColor = Color.FromArgb(255, 255, 255);
        }

        private void btnColor1_Click(object sender, EventArgs e)
        {
            cld.ShowDialog();
            btnColor1.BackColor = cld.Color;

        }

        private void btnColor2_Click(object sender, EventArgs e)
        {
            cld.ShowDialog();
            btnColor2.BackColor = cld.Color;
        }

        private void handToolStripMenuItem_Click(object sender, EventArgs e)
        {
            hand = true;
            pencil = false;
            line = false;
            rect = false;
            circle = false;

        }

        private void pencilToolStripMenuItem_Click(object sender, EventArgs e)
        {
            hand = false;
            pencil = true;
            line = false;
            rect = false;
            circle = false;
        }
        private void lineToolStripMenuItem_Click(object sender, EventArgs e)
        {
            hand = false;
            pencil = false;
            line = true;
            rect = false;
            circle = false;
            
        }

        private void circleToolStripMenuItem_Click(object sender, EventArgs e)
        {
            hand = false;
            pencil = false;
            line = false;
            rect = false;
            circle = true;        
        }

        private void rectToolStripMenuItem_Click(object sender, EventArgs e)
        {
            hand = false;
            pencil = false;
            line = false;
            rect = true;
            circle = false;
        }
        

        private void line1ToolStrip_Click(object sender, EventArgs e)
        {
            thick = 1;
            isSolid = true;                  
        }

        private void line2ToolStrip_Click(object sender, EventArgs e)
        {            
            thick = 2;
            isSolid = true;        
        }

        private void line3ToolStrip_Click(object sender, EventArgs e)
        {
            thick = 3;
            isSolid = true;
        }

        private void line4ToolStrip_Click(object sender, EventArgs e)
        {
            thick = 4;
            isSolid = true;
        }

        private void line5ToolStrip_Click(object sender, EventArgs e)
        {
            thick = 5;
            isSolid = true;
        }

        private void panel1_MouseDown(object sender, MouseEventArgs e)         
        {            
            start.X = e.X;
            start.Y = e.Y;

            if (hand == true)
            {
                isDragOn = true;
                return;
            }
                
            if (isClickedFill)
                pen = new Pen(btnColor2.BackColor);
            else
                pen = new Pen(Color.Black);
        }

        private void panel1_MouseMove(object sender, MouseEventArgs e)
        {            
            if ((start.X == 0) && (start.Y == 0))
                return;
            tempFinishX = finish.X;
            tempFinishY = finish.Y;
            finish.X = e.X;
            finish.Y = e.Y;
            if(hand == true && isDragOn)
            {                
                if(tempFinishX == 0 && tempFinishY == 0)
                {
                    tempFinishX = e.X;
                    tempFinishY = e.Y;
                }

                int gapX = (finish.X - tempFinishX);
                int gapY = (finish.Y - tempFinishY);                             

                for (int i = 0; i < npen; i++)
                {
                    for(int j = 0; j < mypens[i].getLength(); j++)
                    {
                        Point point = new Point(mypens[i].getPoint1(j).X + gapX, mypens[i].getPoint1(j).Y + gapY);
                        mypens[i].setPoint1(j, point);
                    }
                }

                for (int i = 0; i < nline; i++)
                {
                    Point point1 = new Point(mylines[i].getPoint1().X + gapX, mylines[i].getPoint1().Y + gapY);
                    Point point2 = new Point(mylines[i].getPoint2().X + gapX, mylines[i].getPoint2().Y + gapY);
                    mylines[i].setPoint1(point1);
                    mylines[i].setPoint2(point2);
                }

                for(int i = 0; i < nrect; i++)
                {
                    //Point point = new Point(
                    myrects[i].setPoint(myrects[i].getPointX() + gapX, myrects[i].getPointY() + gapY);
                }

                for(int i = 0; i< ncircle; i++)
                {
                    mycircles[i].setRectC2(mycircles[i].getRectC().X + gapX, mycircles[i].getRectC().Y+gapY);
                }

            }
            if(pencil == true)
            {                
                if(isClickedFill)
                    mypens[npen].setPoint(finish, thick, isSolid, btnColor2.BackColor);                
                else
                    mypens[npen].setPoint(finish, thick, isSolid, Color.Black);                
            }
            if (line == true)
            {                
                if (isClickedFill)
                    mylines[nline].setPoint(start, finish, thick, isSolid, btnColor2.BackColor);                
                else
                    mylines[nline].setPoint(start, finish, thick, isSolid, Color.Black);                
            }

            if (rect == true)
            {                
                if (isClickedFill)
                    myrects[nrect].setRect(start, finish, thick, isSolid, btnColor2.BackColor, btnColor1.BackColor);
                else
                    myrects[nrect].setRect(start, finish, thick, isSolid, Color.Black, Color.White);                
            }

            if(circle == true)
            {                
                if (isClickedFill)
                    mycircles[ncircle].setRectC(start, finish, thick, isSolid, btnColor2.BackColor, btnColor1.BackColor);
                else                                    
                    mycircles[ncircle].setRectC(start, finish, thick, isSolid, Color.Black, Color.White);                                    
            }           

            panel1.Invalidate(true);            
            panel1.Update();                        
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {                        
            e.Graphics.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;            
            historyPaint(e);            
            if (pencil == true)
            {
                pen = new Pen(mypens[npen].getLineColor());
                pen.Width = mypens[npen].getThick();
                pen.DashStyle = DashStyle.Solid;
                for (int j = 1; j < mypens[npen].getLength(); j++)
                {
                    e.Graphics.DrawLine(pen, mypens[npen].getPoint1(j), mypens[npen].getPoint1(j - 1));                    
                }
            }
            if (line == true)
            {
                pen = new Pen(mylines[nline].getLineColor());
                pen.Width = mylines[nline].getThick();
                pen.DashStyle = DashStyle.Solid;
                e.Graphics.DrawLine(pen, mylines[nline].getPoint1(), mylines[nline].getPoint2());
            }

            if (rect == true)
            {
                pen = new Pen(myrects[nrect].getLineColor());
                pen.Width = myrects[nrect].getThick();
                pen.DashStyle = DashStyle.Solid;
                e.Graphics.DrawRectangle(pen, myrects[nrect].getRect());
                SolidBrush br = new SolidBrush(myrects[nrect].getBackColor());
                e.Graphics.FillRectangle(br, myrects[nrect].getRect().X + (thick / 2) + (thick % 2),
                    myrects[nrect].getRect().Y + (thick / 2) + (thick % 2),
                    myrects[nrect].getRect().Width - thick, myrects[nrect].getRect().Height - thick);
            }

            if (circle == true)
            {
                pen = new Pen(mycircles[ncircle].getLineColor());
                pen.Width = mycircles[ncircle].getThick();
                pen.DashStyle = DashStyle.Solid;
                e.Graphics.DrawEllipse(pen, mycircles[ncircle].getRectC());
                SolidBrush br2 = new SolidBrush(mycircles[ncircle].getBackColor());
                e.Graphics.FillEllipse(br2, mycircles[ncircle].getRectC().X + (thick / 2) + (thick % 2), 
                    mycircles[ncircle].getRectC().Y + (thick / 2) + (thick % 2),
                    mycircles[ncircle].getRectC().Width - thick, 
                    mycircles[ncircle].getRectC().Height - thick);
            }            

            pen.Width = thick;
            pen.DashStyle = DashStyle.Solid;
            
        }

        private void historyPaint(PaintEventArgs e)
        {            
            e.Graphics.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;            
            int k = 0;
            int m = 0;
            int n = 0;
            int l = 0;
            for (int i = 0; i < order.Count; i++)
            {
                switch (order[i])
                {
                    case 1:
                        pen = new Pen(mypens[k].getLineColor());
                        pen.Width = mypens[k].getThick();
                        pen.DashStyle = DashStyle.Solid;
                        for (int j = 1; j < mypens[k].getLength(); j++)
                        {
                            e.Graphics.DrawLine(pen, mypens[k].getPoint1(j), mypens[k].getPoint1(j - 1));                            
                        }
                        k++;
                        break;

                    case 2:
                        pen = new Pen(mylines[m].getLineColor());
                        pen.Width = mylines[m].getThick();
                        pen.DashStyle = DashStyle.Solid;
                        e.Graphics.DrawLine(pen, mylines[m].getPoint1(), mylines[m].getPoint2());
                        m++;
                        break;

                    case 3:
                        pen = new Pen(myrects[n].getLineColor());
                        pen.Width = myrects[n].getThick();
                        pen.DashStyle = DashStyle.Solid;
                        e.Graphics.DrawRectangle(pen, myrects[n].getRect());
                        SolidBrush br = new SolidBrush(myrects[n].getBackColor());
                        e.Graphics.FillRectangle(br, myrects[n].getRect().X + (thick / 2) + (thick % 2), myrects[n].getRect().Y + (thick / 2) + (thick % 2),
                            myrects[n].getRect().Width - thick, myrects[n].getRect().Height - thick);
                        n++;
                        break;

                    case 4:
                        pen = new Pen(mycircles[l].getLineColor());
                        pen.Width = mycircles[l].getThick();
                        pen.DashStyle = DashStyle.Solid;
                        e.Graphics.DrawEllipse(pen, mycircles[l].getRectC());
                        SolidBrush br2 = new SolidBrush(mycircles[l].getBackColor());
                        e.Graphics.FillEllipse(br2, mycircles[l].getRectC().X + (thick / 2) + (thick % 2), mycircles[l].getRectC().Y + (thick / 2) + (thick % 2),
                            mycircles[l].getRectC().Width - thick, mycircles[l].getRectC().Height - thick);
                        l++;
                        break;
                }
            }

            pen.Width = thick;
            pen.DashStyle = DashStyle.Solid;
        }

        private void panel1_MouseUp(object sender, MouseEventArgs e)
        {
            if(hand == true)
            {
                isDragOn = false;                
            }
            if (pencil == true)
            {
                npen++;
                order.Add(1);
                send(1);
            }
                
            if (line == true)
            {
                nline++;
                order.Add(2);
                send(2);
            }
                
            if (rect == true)
            {
                nrect++;
                order.Add(3);
                send(3);
            }
                
            if (circle == true)
            {
                ncircle++;
                order.Add(4);
                send(4);
            }            

            start.X = 0;
            start.Y = 0;
            finish.X = 0;
            finish.Y = 0;
            tempFinishX = 0;
            tempFinishY = 0;
            
            //보내자 packet으로


        }

        private void send(int type)
        {
            m_Stream = clientModal.client.GetStream();
            for (int i = 0; i < sendBuffer.Length; i++)
            {
                sendBuffer[i] = 0;
            }

            if (type == 1)
            {                               
                Packet.Pen penPacket = new Packet.Pen();
                penPacket.type = (int)PacketType.펜;                
                penPacket.pen = mypens[npen - 1];
                Packet.Serialize(penPacket).CopyTo(sendBuffer, 0);
                m_Stream.Write(sendBuffer, 0, sendBuffer.Length); //보냄
                m_Stream.Flush();                                
            }

            if(type == 2)
            {
                Packet.Line linePacket = new Packet.Line();
                linePacket.type = (int)PacketType.선;
                linePacket.line = mylines[nline - 1];
                Packet.Serialize(linePacket).CopyTo(sendBuffer, 0);
                m_Stream.Write(sendBuffer, 0, sendBuffer.Length);
                m_Stream.Flush();
            }
            if(type == 3)
            {
                Packet.Rect rectPacket = new Packet.Rect();
                rectPacket.type = (int)PacketType.사각형;
                rectPacket.rect = myrects[nrect - 1];
                Packet.Serialize(rectPacket).CopyTo(sendBuffer, 0);
                m_Stream.Write(sendBuffer, 0, sendBuffer.Length);
                m_Stream.Flush();
            }
            if(type == 4)
            {
                Packet.Circle circlePacket = new Packet.Circle();
                circlePacket.type = (int)PacketType.원;
                circlePacket.circle = mycircles[ncircle - 1];
                Packet.Serialize(circlePacket).CopyTo(sendBuffer, 0);
                m_Stream.Write(sendBuffer, 0, sendBuffer.Length);
                m_Stream.Flush();
            }
            if(type == 5)
            {
                textBox1.AppendText(name + " : " + txtMessage.Text);
                textBox1.AppendText("\r\n");

                Packet.Message messagePacket = new Packet.Message();
                messagePacket.type = (int)PacketType.메세지;
                messagePacket.name = name;
                messagePacket.message = txtMessage.Text;
                Packet.Serialize(messagePacket).CopyTo(sendBuffer, 0);
                m_Stream.Write(sendBuffer, 0, sendBuffer.Length);
                m_Stream.Flush();
                txtMessage.Text = "";
            }
                   

}
        private void btnFill_Click(object sender, EventArgs e)
        {
            if (isClickedFill)
                isClickedFill = false;
            else
                isClickedFill = true;
        }

        private void btnSay_Click(object sender, EventArgs e)
        {
            send(5);

        }

        private void txtMessage_KeyUp(object sender, KeyEventArgs e)
        {
            
        }

        private void txtMessage_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                send(5);
            }
        }
    }
}
