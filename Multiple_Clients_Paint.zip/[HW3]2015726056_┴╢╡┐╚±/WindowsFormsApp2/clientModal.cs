﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net;
using System.Net.Sockets;
using System.Threading;
using System.Diagnostics;

namespace WindowsFormsApp2
{
    public partial class clientModal : Form
    {        
        public static TcpClient client = null;
        public bool isConnected = false;
        public static string cliName;
        public clientModal()
        {
            InitializeComponent();            
        }
    
        private void btnModal_Click(object sender, EventArgs e)
        {
            if(txtID.TextLength > 0)
            {
                cliName = txtID.Text;
                isConnected = Connect();
                if (isConnected)
                {
                    clientForm cli = new clientForm();
                    DialogResult dResult = cli.ShowDialog();
                }
            }

            else
            {
                MessageBox.Show("사용자 이름을 입력해주세요");
            }
            
                                          
        }
       
        public bool Connect()
        {            
            client = new TcpClient();
            try
            {
                client.Connect(txtIP.Text, Int32.Parse(txtPort.Text));
            }
            catch
            {
                return false;
            }

            return true;
        }
        private void clientModal_Load(object sender, EventArgs e)
        {
        
        }
    }
}
