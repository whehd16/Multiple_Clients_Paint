﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net;
using System.Net.Sockets;
using System.Threading;
using System.Diagnostics;
using System.Runtime.Serialization.Formatters.Binary;
using System.Drawing.Drawing2D;
using System.IO;
using System.Collections;
using hw3Library;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;

namespace WindowsFormsApp34
{
    public partial class serverForm : Form
    {        
        Thread serverThread;
        Thread listenThread;
        int countClient = 0;
        NetworkStream m_stream;
        static int nRead = 0;
        static byte[] readBuffer = new byte[1024 * 1024];
        static private byte[] sendBuffer = new byte[1024 * 1024];
        static Graphics g;
        static Graphics screen;
        static public Packet.Pen m_pen;
        static public Packet.Line m_line;
        static public Packet.Rect m_rect;
        static public Packet.Circle m_circle;        
        static TcpClient client;
        static List<TcpClient> clients;

        static private List<MyPen> mypens = new List<MyPen>();
        static private List<MyLines> mylines = new List<MyLines>();
        static private List<MyRect> myrects = new List<MyRect>();
        static private List<MyCircle> mycircles = new List<MyCircle>();        
        static private List<int> order = new List<int>();
        static List<NetworkStream> clientsStreams;

        static TextBox messageBox;

        public serverForm()
        {
            InitializeComponent();
        }

        [Serializable]
        public class Data
        {
            public List<int> order = new List<int>();
            public List<MyPen> pens = new List<MyPen>();
            public List<MyLines> lines = new List<MyLines>();
            public List<MyRect> rects = new List<MyRect>();
            public List<MyCircle> circles = new List<MyCircle>();
            
            public Data(List<int> order, List<MyPen> pens, List<MyLines> lines, List<MyRect> rects, List<MyCircle> circles)
            {
                this.order = order;
                this.pens = pens;
                this.lines = lines;
                this.rects = rects;
                this.circles = circles;
            }
        }

        public class DoubleBufferPanel : Panel
        {
            public DoubleBufferPanel()
            {
                this.SetStyle(ControlStyles.DoubleBuffer | ControlStyles.UserPaint |
                    ControlStyles.AllPaintingInWmPaint, true);
                this.UpdateStyles();
            }
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void serverForm_Load(object sender, EventArgs e)
        {
            
            clients = new List<TcpClient>();
            clientsStreams = new List<NetworkStream>();            
            serverThread = new Thread(new ThreadStart(serverAction));
            serverThread.Start();
            

        }

        async static Task listen()
        {            
            while (true)
            {
                if (clients.Count <= 10)
                {                    
                    TcpClient cl = await DlgForm.serverListener.AcceptTcpClientAsync().ConfigureAwait(false);                    
                    clients.Add(cl);
                    sendAll(cl);                    
                    Task.Factory.StartNew(AsyncTcpProcess, cl);                    
                }
                else
                    continue;
            }            
        }
        async static void isConnected()
        {
            clientsStreams.Clear();
            try
            {                
                foreach (TcpClient cli in clients)
                {                    
                    if (cli.Connected)
                    {
                        clientsStreams.Add(cli.GetStream());                        
                    }                 
                }
            }
            catch(Exception e)
            {
                Console.WriteLine(e.Message);
            }           
        }
        async static void sendAll(TcpClient cl)
        {                  
            int penCount = 0;
            int lineCount = 0;
            int recCount = 0;
            int cirCount = 0;
            NetworkStream stream = cl.GetStream();
            
            foreach (int ord in order)
            {                
                switch (ord)
                {
                    case 1:
                        {
                            Packet.Pen penPacket = new Packet.Pen();
                            penPacket.type = (int)PacketType.펜;
                            penPacket.pen = mypens[penCount++];
                            Packet.Serialize(penPacket).CopyTo(sendBuffer, 0);
                            stream.WriteAsync(sendBuffer, 0, 1024 * 1024);
                            stream.Flush();
                            break;
                        }                        
                    case 2:
                        {
                            Packet.Line linePacket = new Packet.Line();
                            linePacket.type = (int)PacketType.선;
                            linePacket.line = mylines[lineCount++];
                            Packet.Serialize(linePacket).CopyTo(sendBuffer, 0);
                            stream.WriteAsync(sendBuffer, 0, sendBuffer.Length);
                            stream.Flush();
                            break;
                        }
                        
                    case 3:
                        {
                            Packet.Rect rectPacket = new Packet.Rect();
                            rectPacket.type = (int)PacketType.사각형;
                            rectPacket.rect = myrects[recCount++];
                            Packet.Serialize(rectPacket).CopyTo(sendBuffer, 0);
                            stream.WriteAsync(sendBuffer, 0, sendBuffer.Length);
                            stream.Flush();
                            break;
                        }
                        
                    case 4:
                        {
                            Packet.Circle circlePacket = new Packet.Circle();
                            circlePacket.type = (int)PacketType.원;
                            circlePacket.circle = mycircles[cirCount++];
                            Packet.Serialize(circlePacket).CopyTo(sendBuffer, 0);
                            stream.WriteAsync(sendBuffer, 0, sendBuffer.Length);
                            stream.Flush();
                            break;
                        }                        
                }               
            }            
            Packet.End end = new Packet.End();
            end.type = (int)PacketType.끝;
            Packet.Serialize(end).CopyTo(sendBuffer, 0);
            stream.WriteAsync(sendBuffer, 0, sendBuffer.Length);
            stream.Flush();
        }

        async static void AsyncTcpProcess(object o)
        {
            TcpClient tc = (TcpClient)o;
            NetworkStream stream = tc.GetStream();
            while (true)
            {
                try
                {                    
                    nRead = await stream.ReadAsync(readBuffer, 0, 1024 * 1024).ConfigureAwait(false);
                }
                catch
                {
                    stream.Close();
                }
                if (nRead > 0)
                {
                    try
                    {
                        Packet packet = (Packet)Packet.Desserialize(readBuffer);
                        isConnected();
                        for (int i = 0; i < sendBuffer.Length; i++)
                        {
                            sendBuffer[i] = 0;
                        }                        
                        switch ((int)packet.type)
                        {
                            case (int)PacketType.펜:
                                {
                                    m_pen = new Packet.Pen();                                    
                                    m_pen = (Packet.Pen)Packet.Desserialize(readBuffer);
                                    mypens.Add(m_pen.pen);
                                    order.Add(1);
                                    Pen pen = new Pen(m_pen.pen.getLineColor());
                                    pen.Width = m_pen.pen.getThick();
                                    for (int j = 1; j < m_pen.pen.getLength(); j++)
                                    {
                                        g.DrawLine(pen, m_pen.pen.getPoint1(j), m_pen.pen.getPoint1(j - 1));
                                    }


                                    Packet.Pen penPacket = new Packet.Pen();                                    
                                    penPacket.type = (int)PacketType.펜;
                                    penPacket.pen = mypens[mypens.Count-1];
                                    Packet.Serialize(penPacket).CopyTo(sendBuffer, 0);
                                    for(int i = 0; i < clientsStreams.Count; i++)
                                    {                                        
                                        if (stream != clientsStreams[i])
                                        {                                            
                                            await clientsStreams[i].WriteAsync(sendBuffer, 0, 1024 * 1024).ConfigureAwait(false);                                            
                                        }
                                        
                                    }
                                    storeData();
                                    break;
                                }
                            case (int)PacketType.선:
                                {
                                    m_line = new Packet.Line();
                                    m_line = (Packet.Line)Packet.Desserialize(readBuffer);
                                    mylines.Add(m_line.line);
                                    order.Add(2);
                                    Pen pen = new Pen(m_line.line.getLineColor());
                                    pen.Width = m_line.line.getThick();
                                    g.DrawLine(pen, m_line.line.getPoint1(), m_line.line.getPoint2());


                                    Packet.Line linePacket = new Packet.Line();
                                    linePacket.type = (int)PacketType.선;
                                    linePacket.line = mylines[mylines.Count - 1];
                                    Packet.Serialize(linePacket).CopyTo(sendBuffer, 0);
                                    for(int i = 0;i<clientsStreams.Count; i++)
                                    {                                        
                                        if (stream != clientsStreams[i])
                                        {                                            
                                            await clientsStreams[i].WriteAsync(sendBuffer, 0, 1024 * 1024).ConfigureAwait(false);                                            
                                        }
                                    }

                                    storeData();
                                    break;
                                }
                            case (int)PacketType.사각형:
                                {
                                    m_rect = new Packet.Rect();
                                    m_rect = (Packet.Rect)Packet.Desserialize(readBuffer);
                                    myrects.Add(m_rect.rect);
                                    order.Add(3);
                                    Pen pen = new Pen(m_rect.rect.getLineColor());
                                    pen.Width = m_rect.rect.getThick();
                                    g.DrawRectangle(pen, m_rect.rect.getRect());
                                    SolidBrush br = new SolidBrush(m_rect.rect.getBackColor());
                                    g.FillRectangle(br, m_rect.rect.getRect().X + (m_rect.rect.getThick() / 2) + (m_rect.rect.getThick() % 2),
                                      m_rect.rect.getRect().Y + (m_rect.rect.getThick() / 2) + (m_rect.rect.getThick() % 2),
                                      m_rect.rect.getRect().Width - m_rect.rect.getThick(), m_rect.rect.getRect().Height - m_rect.rect.getThick());


                                    Packet.Rect rectPacket = new Packet.Rect();
                                    rectPacket.type = (int)PacketType.사각형;
                                    rectPacket.rect = myrects[myrects.Count - 1];
                                    Packet.Serialize(rectPacket).CopyTo(sendBuffer, 0);
                                    for (int i = 0; i < clientsStreams.Count; i++)
                                    {                                        
                                        if (stream != clientsStreams[i])
                                        {                                            
                                            await clientsStreams[i].WriteAsync(sendBuffer, 0, 1024 * 1024).ConfigureAwait(false);                                            
                                        }
                                    }

                                    storeData();
                                    break;
                                }
                            case (int)PacketType.원:
                                {
                                    m_circle = new Packet.Circle();
                                    m_circle = (Packet.Circle)Packet.Desserialize(readBuffer);
                                    mycircles.Add(m_circle.circle);
                                    order.Add(4);
                                    Pen pen = new Pen(m_circle.circle.getLineColor());
                                    pen.Width = m_circle.circle.getThick();
                                    g.DrawEllipse(pen, m_circle.circle.getRectC());
                                    SolidBrush br = new SolidBrush(m_circle.circle.getBackColor());
                                    g.FillEllipse(br, m_circle.circle.getRectC().X + (m_circle.circle.getThick() / 2) + (m_circle.circle.getThick() % 2),
                                      m_circle.circle.getRectC().Y + (m_circle.circle.getThick() / 2) + (m_circle.circle.getThick() % 2),
                                      m_circle.circle.getRectC().Width - m_circle.circle.getThick(), m_circle.circle.getRectC().Height - m_circle.circle.getThick());


                                    Packet.Circle circlePacket = new Packet.Circle();
                                    circlePacket.type = (int)PacketType.원;
                                    circlePacket.circle = mycircles[mycircles.Count - 1];
                                    Packet.Serialize(circlePacket).CopyTo(sendBuffer, 0);
                                    for (int i = 0; i < clientsStreams.Count; i++)
                                    {                                        
                                        if (stream != clientsStreams[i])
                                        {
                                            
                                            await clientsStreams[i].WriteAsync(sendBuffer, 0, 1024 * 1024).ConfigureAwait(false);                                            
                                        }
                                    }
                                    storeData();
                                    break;
                                }
                            case (int)PacketType.메세지:
                                {
                                    Packet.Message m_message = new Packet.Message();
                                    m_message = (Packet.Message)Packet.Desserialize(readBuffer);
                                    messageBox.AppendText(m_message.name + " : " + m_message.message);
                                    messageBox.AppendText("\r\n");

                                    Packet.Message messagePacket = new Packet.Message();
                                    messagePacket.type = (int)PacketType.메세지;
                                    messagePacket.name = m_message.name;
                                    messagePacket.message = m_message.message;
                                    Packet.Serialize(messagePacket).CopyTo(sendBuffer, 0);
                                    for(int i =0; i < clientsStreams.Count;i++)
                                    {
                                        if (stream != clientsStreams[i])
                                        {
                                            await clientsStreams[i].WriteAsync(sendBuffer, 0, 1024 * 1024).ConfigureAwait(false);
                                        }
                                    }                                                                        
                                    break;
                                }
                        }                        
                    }
                    catch (Exception e)
                    {                        
                        stream.Close();
                        tc.Close();
                        clients.Remove((TcpClient)o);
                        return;
                    }
                    stream.Flush();
                    nRead = 0;
                }
               
            }
        }

        public void readData()
        {           
            Stream stm = File.Open("data.txt", FileMode.OpenOrCreate, FileAccess.Read);
            BinaryFormatter bf = new BinaryFormatter();           
            Data data1;
            try
            {
                data1 = (Data)bf.Deserialize(stm);
            }
            catch(Exception e)
            {                
                return;
            }
            order = data1.order;
            mypens = data1.pens;
            mylines = data1.lines;
            myrects = data1.rects;
            mycircles = data1.circles;
           
                        
            int num_pens = 0;
            int num_lines = 0;
            int num_rects = 0;
            int num_circles = 0;            
            foreach(int i in order)
            {                
                switch (i){
                    case 1:
                        {
                            MyPen mypen = mypens[num_pens++];
                            Pen pen = new Pen(mypen.getLineColor());
                            pen.Width = mypen.getThick();
                            for (int j = 1; j < mypen.getLength(); j++)
                            {
                                g.DrawLine(pen, mypen.getPoint1(j), mypen.getPoint1(j - 1));
                            }
                            break;
                        }
                    case 2:
                        {
                            MyLines myline = mylines[num_lines++];                                                        
                            Pen pen = new Pen(myline.getLineColor());
                            pen.Width = myline.getThick();
                            g.DrawLine(pen, myline.getPoint1(), myline.getPoint2());
                            break;
                        }
                    case 3:
                        {
                            MyRect myrect = myrects[num_rects++];
                            Pen pen = new Pen(myrect.getLineColor());
                            pen.Width = myrect.getThick();
                            g.DrawRectangle(pen, myrect.getRect());
                            SolidBrush br = new SolidBrush(myrect.getBackColor());
                            g.FillRectangle(br, myrect.getRect().X + (myrect.getThick() / 2) + (myrect.getThick() % 2),
                              myrect.getRect().Y + (myrect.getThick() / 2) + (myrect.getThick() % 2),
                              myrect.getRect().Width - myrect.getThick(), myrect.getRect().Height - myrect.getThick());
                            break;                            
                        }
                    case 4:
                        {
                            MyCircle mycircle = mycircles[num_circles++];                           
                            Pen pen = new Pen(mycircle.getLineColor());
                            pen.Width = mycircle.getThick();
                            g.DrawEllipse(pen, mycircle.getRectC());
                            SolidBrush br = new SolidBrush(mycircle.getBackColor());
                            g.FillEllipse(br, mycircle.getRectC().X + (mycircle.getThick() / 2) + (mycircle.getThick() % 2),
                              mycircle.getRectC().Y + (mycircle.getThick() / 2) + (mycircle.getThick() % 2),
                              mycircle.getRectC().Width - mycircle.getThick(), mycircle.getRectC().Height - mycircle.getThick());
                            break;
                        }

                }
            }

            stm.Close();
            stm = null;
            bf = null;
        }

        public static void storeData()
        {
            Data data1 = new Data(order, mypens, mylines, myrects, mycircles);
            Stream stm = File.Open("data.txt", FileMode.Create, FileAccess.ReadWrite);
            BinaryFormatter bf = new BinaryFormatter();
            bf.Serialize(stm, data1);            
            stm.Close();
            stm = null;
            bf = null;

        }
        public void serverAction()
        {
            g = this.serverPanel.CreateGraphics();
            g.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
            messageBox = this.textBox1;
            readData();
            listen().Wait();
        }

        private void serverForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            DlgForm.serverListener.Stop();
        }
    }
}

