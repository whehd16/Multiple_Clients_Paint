﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net;
using System.Net.Sockets;
using System.Threading;
using System.Diagnostics;

namespace WindowsFormsApp34
{
    public partial class DlgForm : Form
    {
        public static TcpListener serverListener = null;
 

        public DlgForm()
        {
            InitializeComponent();
        }

        private void btnModal_Click(object sender, EventArgs e)
        {
            IPAddress localAddr = IPAddress.Parse(txtIP.Text);
            Int32 port = Int32.Parse(txtPort.Text);
            serverListener = new TcpListener(localAddr, port);
            serverListener.Server.SetSocketOption(SocketOptionLevel.Socket, SocketOptionName.ReuseAddress, true);
            serverListener.Start();
            serverForm ser = new serverForm();
            DialogResult dResult = ser.ShowDialog();
                               
        }

        
        private void DlgForm_Load(object sender, EventArgs e)
        {

        }
    }
}
