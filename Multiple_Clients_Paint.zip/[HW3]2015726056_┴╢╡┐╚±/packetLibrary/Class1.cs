﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using System.Reflection;


namespace hw3Library
{
    public enum PacketType
    {
        펜 = 0,
        선,
        사각형,
        원,
        메세지,
        끝
    }
    public enum PacketSendERROR
    {
        정상 = 0,
        에러
    }
    [Serializable]
    public class Packet
    {
        public int Length;
        public int type;

        public Packet()
        {
            this.Length = 0;
            this.type = 0;
        }

        public static byte[] Serialize(Object o)
        {
            MemoryStream ms = new MemoryStream(1024 * 4);
            BinaryFormatter bf = new BinaryFormatter();
            bf.Serialize(ms, o);
            return ms.ToArray();
        }

        sealed class AllowAllAssemblyVersionsDeserializationBinder : System.Runtime.Serialization.SerializationBinder
        {
            public override Type BindToType(string assemblyName, string typeName)
            {
                Type typeToDeserialize = null;

                String currentAssembly = Assembly.GetExecutingAssembly().FullName;

                // In this case we are always using the current assembly
                assemblyName = currentAssembly;

                // Get the type using the typeName and assemblyName
                typeToDeserialize = Type.GetType(String.Format("{0}, {1}",
                    typeName, assemblyName));

                return typeToDeserialize;
            }
        }

        public static Object Desserialize(byte[] bt)
        {
            MemoryStream ms = new MemoryStream(1024 * 4);
            foreach (byte b in bt)
            {
                ms.WriteByte(b);
            }
            ms.Position = 0;
            BinaryFormatter bf = new BinaryFormatter();
            bf.Binder = new AllowAllAssemblyVersionsDeserializationBinder();
            Object obj = bf.Deserialize(ms);
            ms.Close();
            return obj;
        }

        [Serializable]
        public class Initialize : Packet
        {
            public string Data = null;
        }

        [Serializable]
        public class Pen : Packet
        {
            public MyPen pen;

            public Pen()
            {
                pen = new MyPen();
            }
        }

        [Serializable]
        public class Line : Packet
        {
            public MyLines line;

            public Line()
            {
                line = new MyLines();
            }
        }
        [Serializable]
        public class Rect : Packet           
        {
            public MyRect rect;

            public Rect()
            {
                rect = new MyRect();
            }
              
           
        }
        [Serializable]
        public class Circle : Packet
        {
            public MyCircle circle;

            public Circle()
            {
                circle = new MyCircle();
            }

        }

        [Serializable]
        public class End : Packet
        {
            public int end;
            public End()
            {
                end = 0;
            }
        }
        
        [Serializable]
        public class Message : Packet
        {
            public string name;
            public string message;
            public Message()
            {
                name = null;
                message = null;
            }
        }


    }
    class ClientClass1
    {
    }
}
