﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;
using System.Drawing;

namespace hw3Library
{
    [Serializable]
    public class MyCircle
    {
        private Rectangle rectC;
        private int thick;
        private bool isSolid;
        private bool isFilled;
        private Color lineColor;
        private Color backColor;

        public MyCircle()
        {
            rectC = new Rectangle();
            thick = 1;
            isSolid = true;
        }

        public void setRectC(Point start, Point finish, int thick, bool isSolid, Color lineColor, Color backColor)
        {
            rectC.X = Math.Min(start.X, finish.X);
            rectC.Y = Math.Min(start.Y, finish.Y);
            rectC.Width = Math.Abs(start.X - finish.X);
            rectC.Height = Math.Abs(start.Y - finish.Y);
            this.thick = thick;
            this.isSolid = isSolid;
            this.lineColor = lineColor;
            this.backColor = backColor;            
        }
        public void setRectC1(Point start, Point finish)
        {
            rectC.X = Math.Min(start.X, finish.X);
            rectC.Y = Math.Min(start.Y, finish.Y);
            rectC.Width = Math.Abs(start.X - finish.X);
            rectC.Height = Math.Abs(start.Y - finish.Y);
        }
        public void setRectC2(int x ,int y)
        {
            rectC.X = x;
            rectC.Y = y;
        }
        public void setIsFilled(bool isFilled)
        {
            this.isFilled = isFilled;
        }

        public bool getIsFilled()
        {
            return this.isFilled;
        }

        public Color getLineColor()
        {
            return lineColor;
        }

        public Color getBackColor()
        {
            return backColor;
        }
       
        public Rectangle getRectC()
        {
            return rectC;
        }

        public int getThick()
        {
            return thick;
        }

        public bool getSolid()
        {
            return isSolid;
        }
    }
}
