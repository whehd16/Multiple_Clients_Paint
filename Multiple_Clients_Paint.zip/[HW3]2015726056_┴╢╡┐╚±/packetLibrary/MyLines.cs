﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;
using System.Drawing;
namespace hw3Library
{
    [Serializable]
    public class MyLines
    {
        private Point[] point = new Point[2];
        private int thick;
        private bool isSolid;
        private bool isFilled;
        private Color lineColor;
        
        public MyLines()
        {
            point[0] = new Point();
            point[1] = new Point();
            thick = 1;
            isSolid = true;        
        }
        public void setPoint(Point start, Point finish, int thick, bool isSolid, Color lineColor)
        {
            point[0] = start;
            point[1] = finish;
            this.thick = thick;
            this.isSolid = isSolid;
            this.lineColor = lineColor;

        }

        public Color getLineColor()
        {
            return lineColor;
        }

        public void setPoint1(Point point)
        {
            this.point[0] = point;
        }

        public void setPoint2(Point point)
        {
            this.point[1] = point;
        }


        public Point getPoint1()
        {
            return point[0];
        }
        public Point getPoint2()
        {
            return point[1];
        }

        public int getThick()
        {
            return thick;
        }

        public bool getSolid()
        {
            return isSolid;
        }

    }
}
