﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;
using System.Drawing;
namespace hw3Library
{
    [Serializable]
    public class MyPen
    {       
        private List<Point> pointList;
        private int thick;
        private bool isSolid;
        private bool isFilled;
        private Color lineColor;

        public MyPen()        
        {
            pointList = new List<Point>();   
            thick = 1;
            isSolid = true;
        }

        public void setPoint(Point start, int thick, bool isSolid, Color lineColor)
        {
            pointList.Add(start);
            this.thick = thick;
            this.isSolid = isSolid;
            this.lineColor = lineColor;
        }
        public void setPoint1(int index, Point point)
        {
            pointList[index] = point;
        }
        public Color getLineColor()
        {
            return lineColor;
        }

        public int getLength()
        {
            return pointList.Count;
        }
        public Point getPoint1(int index)
        {
            return pointList[index];
        }       

        public int getThick()
        {
            return thick;
        }

        public bool getSolid()
        {
            return isSolid;
        }

    }
}
